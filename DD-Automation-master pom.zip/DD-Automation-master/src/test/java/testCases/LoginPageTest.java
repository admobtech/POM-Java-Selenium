package testCases;

import com.relevantcodes.extentreports.LogStatus;
import main.dd.core.base.TestBase;
import main.dd.core.util.listeners.SuiteListener;
import main.dd.pageObjects.LoginPage;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;


public class LoginPageTest extends TestBase {
    String URL = "http://3.211.144.188:3000";
    LoginPage login;


    public LoginPageTest() throws IOException {
        super();
    }

    @BeforeTest
    public void generateTestReport() {
        if (SuiteListener.reports != null) {
            SuiteListener.test = SuiteListener.reports.startTest("Positive login test");
            SuiteListener.test.log(LogStatus.INFO, "Positive login test" + " is started");
            SuiteListener.test.setDescription("We input the right username and password.");
        }
    }

    @Test(priority = 1, description = "Open login page")
    public void openLoginPage() {
        login = new LoginPage(getDriver());
        this.getDriver().navigate().to(URL);
        login.waitForPage();
        Assert.assertEquals(login.getTheTitle(), "DigitalDesignerFrontend");
    }

    @Test(priority = 2, description = "Sign in to Digital Designer")
    public void signIn() {
        login.GetLogin(getProp().getProperty("username"), getProp().getProperty("password"));
    }


    @AfterTest
    public void closeTestReport() {
        if (SuiteListener.test != null)
            SuiteListener.reports.endTest(SuiteListener.test);
    }
}

