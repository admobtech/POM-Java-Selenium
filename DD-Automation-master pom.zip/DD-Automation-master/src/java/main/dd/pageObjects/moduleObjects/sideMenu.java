package main.dd.pageObjects.moduleObjects;

import main.dd.core.base.BasePage;
import org.openqa.selenium.WebDriver;

public class sideMenu extends BasePage {

    sideMenu(WebDriver driver){
        super(driver);
    }
}
