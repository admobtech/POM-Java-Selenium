package main.dd.core.util;

import dd.core.util.OLselect;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;

public class SeleniumRepo  {

    public static void waitForLoad(WebDriver driver) {
        ExpectedCondition<Boolean> expectation = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
                    }
                };
        try {
            Thread.sleep(3000);
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(expectation);
        } catch (Throwable error) {
            Assert.fail("Timeout waiting for Page Load Request to complete.");
        }
    }


    public static void highlightElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
                element, "border: 2px solid DeepPink;");
    }

    public static void doubleClick(WebElement element, WebDriver driver) {
        if ((driver != null) && (element != null))
            (new Actions(driver)).doubleClick(element).build().perform();
    }


    public static void mousehovering(WebElement mouseOverElement, WebDriver driver) {
        Actions builder = new Actions(driver);  // Configure the Action
        Action mouseOver =builder.moveToElement(mouseOverElement).build(); // Get the action
        mouseOver.perform(); // Execute the Action
    }

    public static void dropDownListBox(WebElement dropDownListBox, Object value, WebDriver driver) {
        OLselect dropdown = new OLselect(dropDownListBox);
        if(value instanceof String)
            dropdown.selectByID((String)value);
        if(value instanceof Integer)
            dropdown.selectByIndex((Integer) value);
    }


    public static void takeScreenshotAtEndOfTest(WebDriver driver) throws IOException {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String currentDir = System.getProperty("user.dir");
        FileUtils.copyFile(scrFile, new File(currentDir + "/screenshots/" + System.currentTimeMillis() + ".png"));
    }

}
