package main.dd.pageObjects;


import main.dd.core.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProjectsPage extends BasePage {

    public ProjectsPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath ="//h1[contains(text(),'Projects')]")
    WebElement projectsTitle;

    @FindBy(id = "create-solution")
    WebElement newProjectComponent;

    @FindBy(id="sort-area")
    WebElement dropDownMenuSortedBy;

    @FindBy(id="selected-value")
    WebElement dropDownMenuSortedBySelectedValue;

    @FindBy(id="search-input")
    WebElement searchInput;

    @FindBy(id="ico-search")
    WebElement searchIcon;

    @FindBy(id="grid-view-btn")
    WebElement gridView;

    @FindBy(id="table-view-btn")
    WebElement iconsView;

    public void waitForPage(){
        waitForElementToAppear(By.id("create-solution"));
    }
    public String validatedTitle (){
        return projectsTitle.getText();
    }

    public void selectDateCreatedDropDown(){
       // SeleniumRepo.dropDownListBox(dropDownMenuSortedBy,"option-0",driver);
        driver.findElement(By.id("option-0")).click();
    }

    public void clickMenu(){
        dropDownMenuSortedBy.click();
    }

    public void selectProjectNameDropDown(){
      //  SeleniumRepo.dropDownListBox(dropDownMenuSortedBy," Project Name ",driver);
        driver.findElement(By.id("option-1")).click();
    }

    public void selectLastEditDropDown(){
       // SeleniumRepo.dropDownListBox(dropDownMenuSortedBy,"option-2",driver);
        driver.findElement(By.id("option-2")).click();
    }

    public boolean isSelected(String text){
        if(dropDownMenuSortedBySelectedValue.getText().equals(text))
            return true;
        return false;
    }


}
