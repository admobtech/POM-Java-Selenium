package main.dd.core.setup;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class  Browser {
    public static boolean headless = false;


    public static WebDriver setdriver(DriverType driverType) {
        WebDriver driver;
        switch (driverType) {
            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            case IE:
                WebDriverManager.iedriver().setup();
                driver = new InternetExplorerDriver();
                break;
            default:
                driver=setChrome();
        }
        return driver;
    }



    public static WebDriver setChrome(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        if (headless) {
            options.addArguments("--no-sandbox");
            options.addArguments("--headless");
        }
        return new ChromeDriver(options);
    }


}
