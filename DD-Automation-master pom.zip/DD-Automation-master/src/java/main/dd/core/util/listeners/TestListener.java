package main.dd.core.util.listeners;

import com.relevantcodes.extentreports.LogStatus;
import main.dd.core.base.FactoryDriver;
import lombok.extern.log4j.Log4j;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import java.io.File;
import java.io.IOException;


@Log4j
public class TestListener implements ITestListener {

    public TestListener() throws IOException {
    }

    public void onStart(){

    }
    public void onTestStart(ITestResult result) {

        log.info(result.getMethod().getDescription() + "test is started");
//        SuiteListener.test.log(LogStatus.INFO, result.getMethod().getDescription() + "test is started");
    }

    public void onTestSuccess(ITestResult result) {
        log.info(result.getMethod().getMethodName() + "test is passed");
        SuiteListener.test.log(LogStatus.PASS, result.getMethod().getDescription() + "test is passed");
    }

    public void onTestFailure(ITestResult result) {
        log.error(result.getMethod().getMethodName() + "test is failed");
        SuiteListener.test.log(LogStatus.FAIL, result.getMethod().getDescription() + "test is failed");
        TakesScreenshot ts = (TakesScreenshot) FactoryDriver.getDriver();
        File src = ts.getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File(System.getProperty("user.home") +
                    "/images/" + result.getMethod().getMethodName() + ".png"));
            String file = SuiteListener.test.addScreenCapture(System.getProperty("user.home") +
                    "/images/" + result.getMethod().getMethodName() + ".png");
            SuiteListener.test.log(LogStatus.FAIL, result.getMethod().getDescription() + "test is failed", file);
            SuiteListener.test.log(LogStatus.FAIL, result.getMethod().getDescription() + "test is failed", result.getThrowable().getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onTestSkipped(ITestResult result) {
        log.info(result.getMethod().getMethodName() + "test is skipped");
        SuiteListener.test.log(LogStatus.SKIP, result.getMethod().getMethodName() + "test is skipped");
    }

    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        log.info("on test success within percentage");
    }

    public void onStart(ITestContext context) {
        log.info("Start test " + context.getName());
    }

    public void onFinish(ITestContext context) {
        log.info("on finish " + context.getName());
    }
}