package main.dd.core.util.listeners;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import lombok.extern.log4j.Log4j;
import main.dd.core.util.Meteoroid;
import org.testng.ISuite;
import org.testng.ISuiteListener;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static main.dd.core.base.BaseFinal.REPORTS_PATH;


@Log4j
public class SuiteListener implements ISuiteListener {

    public static ExtentReports reports =null;
    public static ExtentTest test=null;
    public static String nameReport ;
    public SuiteListener() throws IOException {
    }

    @Override
    public void onStart(ISuite iSuite) {
        nameReport = REPORTS_PATH + "/reports-" + iSuite.getName()
                + new SimpleDateFormat("yyyy-MM-dd hh-mm-ss-ms").
                format(new Date()) + ".html";
       log.info("onStart: before suite starts");
        reports =new ExtentReports(nameReport);
    }

    @Override
    public void onFinish(ISuite iSuite) {
        reports.flush();
        try {
            Meteoroid.sendSlack();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }
}
