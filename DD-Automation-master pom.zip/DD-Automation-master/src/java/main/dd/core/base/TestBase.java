package main.dd.core.base;


import main.dd.core.setup.Browser;
import main.dd.core.setup.DriverType;
import lombok.Getter;
import lombok.Setter;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


import static main.dd.core.base.BaseFinal.RESOURCES_PATH;




@Getter
@Setter
public class TestBase {
    private WebDriver driver;
    private Properties prop;


    public TestBase() throws IOException {
        prop = new Properties();
        FileInputStream ip = new FileInputStream(RESOURCES_PATH+"/config.properties");
        prop.load(ip);
    }

    @BeforeClass
    public void initTest() throws IOException {
        Browser.headless = Boolean.parseBoolean(prop.getProperty("headless"));
        System.out.println(System.getProperty("propertyName"));
        this.driver = FactoryDriver.getDriver(DriverType.CHROME);
    }


    @AfterSuite(alwaysRun=true)
    public void closeDriver() {
        FactoryDriver.closeDriver();
    }

}
