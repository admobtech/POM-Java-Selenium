package main.dd.core.setup;

public enum DriverType {
    FIREFOX,
    CHROME,
    IE,
}
