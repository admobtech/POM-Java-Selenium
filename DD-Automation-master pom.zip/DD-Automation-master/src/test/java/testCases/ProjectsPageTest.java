package testCases;

import main.dd.core.base.TestBase;
import main.dd.pageObjects.ProjectsPage;

import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class ProjectsPageTest extends TestBase {
    ProjectsPage projectsPage;

    public ProjectsPageTest() throws IOException {
        super();
    }

    @Test(priority = 3)
    public void openHomePage()
    {
        projectsPage = new ProjectsPage(getDriver());
        projectsPage.waitForPage();
        Assert.assertEquals(projectsPage.validatedTitle(),"Projects");
    }

    @Test(priority = 4)
    public void selectDateCreatedDropDown(){
        projectsPage.clickMenu();
        projectsPage.selectDateCreatedDropDown();
        Assert.assertTrue(projectsPage.isSelected("Date Created"));
    }

    @Test(priority = 5)
    public void selectDProjectNameDropDown(){
        projectsPage.clickMenu();
        projectsPage.selectProjectNameDropDown();
        Assert.assertTrue(projectsPage.isSelected("Project Name"));
    }

    @Test(priority = 6)
    public void selectLastEditDropDown() {
        projectsPage.clickMenu();
        projectsPage.selectLastEditDropDown();
        Assert.assertTrue(projectsPage.isSelected("Last Edit"));
    }
}
