package main.dd.core.base;

public interface BaseFinal {
    String ROOT_URL = "http://3.211.144.188:3000";
    long PAGE_LOAD_TIMEOUT = 30;
    long IMPLICIT_WAIT = 30;
    String RESOURCES_PATH = "src/java/main/resources";
    String REPORTS_PATH = "Reports";
}
