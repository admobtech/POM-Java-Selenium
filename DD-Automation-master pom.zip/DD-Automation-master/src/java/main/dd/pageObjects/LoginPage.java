package main.dd.pageObjects;

import main.dd.core.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) {
        super(driver);

    }

    @FindBy(id ="email")
    WebElement username;

    @FindBy(id="password")
    WebElement password;

    @FindBy(id="signInBtn")
    WebElement signInBtn;

    public void waitForPage(){

        waitForElementToAppear(By.className("ol-logo"));
    }

    public String getTheTitle(){
        return driver.getTitle();
    }

    public void GetLogin(String us, String ps  ){
        username.sendKeys(us);
        password.sendKeys(ps);
        signInBtn.click();

    }

}
