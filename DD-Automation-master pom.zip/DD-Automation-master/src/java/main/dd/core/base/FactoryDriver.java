package main.dd.core.base;

import main.dd.core.setup.Browser;
import main.dd.core.setup.DriverType;
import main.dd.core.util.listeners.WebEventListener;
import lombok.Getter;
import lombok.Setter;
import main.dd.core.base.BaseFinal;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Setter
@Getter
public class FactoryDriver {

    private static FactoryDriver instance = null;
    private WebDriver driver;
    private EventFiringWebDriver e_driver;
    private WebEventListener eventListener;


    private FactoryDriver(DriverType driverType) throws IOException {
        this.driver = Browser.setdriver(driverType);
        initialization();
    }


    public void initialization() throws IOException {
        e_driver = new EventFiringWebDriver(driver);
        // Now create object of EventListerHandler to register it with EventFiringWebDriver
        eventListener = new WebEventListener();
        e_driver.register(eventListener);
        this.driver = e_driver;
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(BaseFinal.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(BaseFinal.IMPLICIT_WAIT, TimeUnit.SECONDS);
    }

    public static WebDriver getDriver(DriverType driverType) throws IOException {
        if (instance == null) {
            instance = new FactoryDriver(driverType);
        }
        return instance.driver;
    }

    public static void closeDriver() {
        if (instance != null && instance.driver != null) {
            instance.driver.close();
            instance.driver.quit();
            instance = null;
        }
    }

    public static WebDriver restartDriver(DriverType driverType) throws IOException {
        FactoryDriver.closeDriver();
        return FactoryDriver.getDriver(driverType);
    }

    public static WebDriver getDriver(){
        return instance.driver;
    }


}
